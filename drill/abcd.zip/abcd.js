
const abcd = () => {
	console.log('abcd');
}

abcd();